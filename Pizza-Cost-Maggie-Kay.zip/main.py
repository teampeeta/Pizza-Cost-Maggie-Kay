print ("Welcome to Maggie's Pizza Place!")

# user enters the pizza size
diameter = int(input("Enter the diameter (inches) : "))

#Declare constants
RENTAL_COST = 1
MATERIALS = 0.5
LABOUR_COST = 0.75
HST = 0.13

#Calculate the subtotal
subtotal = RENTAL_COST + LABOUR_COST + MATERIALS * diameter

#Calculate the tax
tax = subtotal * HST

#Calculate the total
total = tax + subtotal

#Display the subtotal, tax, and total
print("The subtotal of your pizza is $" + str(subtotal))
print ("The total cost of your pizza is ${:0.2f}.". format(total))